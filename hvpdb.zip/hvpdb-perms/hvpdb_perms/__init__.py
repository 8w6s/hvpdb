import time
from typing import Optional
from hvpdb.core import HVPDB
from .cli import app

class PermissionManager:
    """
    Handles User Management and RBAC for HVPDB.
    Strictly enforces Root-only access for management operations.
    """
    def __init__(self, db: HVPDB):
        self.db = db

    def _is_root(self, username: str) -> bool:
        """Checks if the user is root."""
        return username == "root"

    def _is_admin(self, user_data: dict) -> bool:
        """Checks if the user has admin role."""
        return user_data.get("role") == "admin"

    def _can_manage_group(self, user_data: dict, group_name: str) -> bool:
        """Checks if user can manage a specific group."""
        user_groups = user_data.get("groups", [])
        return "*" in user_groups or group_name in user_groups

    def _check_access(self, required_group: str = None):
        """
        Checks if current user has permission to perform action.
        - Root/Admin: Full Access.
        - User: Can only grant/revoke groups they possess (Delegation).
        """
        caller = getattr(self.db, 'current_user', None)
        
        # 1. Root Access (No user set = CLI Master Key, or 'root' user)
        if not caller or self._is_root(caller):
            return
            
        caller_data = self.db.storage.data["users"].get(caller)
        if not caller_data:
            raise PermissionError("Access Denied: Caller not found.")
            
        # 2. Admin Access
        if self._is_admin(caller_data):
            return
            
        # 3. Delegation Check
        # If required_group is None, it means general management (create user), which only Admin can do.
        if required_group is None:
             raise PermissionError("Access Denied: Only Root/Admin can perform this action.")
             
        # Check if Caller has access to the group they are trying to grant/revoke
        if self._can_manage_group(caller_data, required_group):
            return
            
        raise PermissionError(f"Access Denied: You do not have permission to manage group '{required_group}'.")

    def create_user(self, username: str, password: str, role: str = "user"):
        self._check_access() # Only Admin/Root
        
        # TODO: Audit Log implementation is out of scope for v0.1.
        # Future versions should log: who created whom, and when.
        
        if username == "root":
            raise ValueError("Root user cannot be created or modified.")
            
        if self.db.is_cluster:
            raise NotImplementedError("User management not supported in cluster mode yet.")

        if username in self.db.storage.data["users"]:
            raise ValueError(f"User '{username}' already exists.")
            
        # Use public API
        pass_hash = self.db.hash_user_password(password)
        
        self.db.storage.data["users"][username] = {
            "password_hash": pass_hash,
            "role": role,
            "groups": [],
            "created_at": time.time()
        }
        self.db.storage._dirty = True

    def grant(self, username: str, group_name: str):
        self._check_access(required_group=group_name)
        
        if username == "root":
             raise ValueError("Root user permissions cannot be modified.")

        if username not in self.db.storage.data["users"]:
            raise ValueError(f"User '{username}' not found.")
            
        target_user = self.db.storage.data["users"][username]
        
        # Prevent privilege escalation: Cannot modify Admins unless you are Admin
        if target_user.get("role") == "admin":
             caller = getattr(self.db, 'current_user', None)
             if caller and not self._is_root(caller):
                 caller_data = self.db.storage.data["users"].get(caller)
                 if not self._is_admin(caller_data):
                     raise PermissionError("Access Denied: You cannot modify an Admin user.")
        
        if group_name not in target_user["groups"]:
            target_user["groups"].append(group_name)
            self.db.storage._dirty = True

    def revoke(self, username: str, group_name: str):
        self._check_access(required_group=group_name)
        
        if username == "root":
             raise ValueError("Root user permissions cannot be modified.")

        if username not in self.db.storage.data["users"]:
            raise ValueError(f"User '{username}' not found.")
            
        target_user = self.db.storage.data["users"][username]
        
        # Prevent privilege escalation: Cannot modify Admins unless you are Admin
        if target_user.get("role") == "admin":
             caller = getattr(self.db, 'current_user', None)
             if caller and not self._is_root(caller):
                 caller_data = self.db.storage.data["users"].get(caller)
                 if not self._is_admin(caller_data):
                     raise PermissionError("Access Denied: You cannot modify an Admin user.")

        if group_name in target_user["groups"]:
            target_user["groups"].remove(group_name)
            self.db.storage._dirty = True

    def list_users(self):
        # Any authenticated user can list users? Or only Admin?
        # Let's restrict to Admin for now, or allow reading public info.
        # For simplicity, allow anyone to list names, but maybe mask details.
        # But CLI usually implies Admin.
        self._check_access() 
        return self.db.storage.data.get("users", {})
