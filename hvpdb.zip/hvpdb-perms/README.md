# HVPDB Permissions Plugin (hvpdb-perms)

🔒 **Production-grade Permission Management for HVPDB.**

This plugin adds Role-Based Access Control (RBAC) and user management capabilities to HVPDB. It is designed with a "security-first" mindset, focusing on safety, simplicity, and capability-based delegation.

## Features ✨

*   **Secure Password Hashing**: Uses HVPDB's core cryptographic engine (Argon2id/Scrypt).
*   **Root Immutability**: The `root` user is strictly protected. It cannot be modified, revoked, or locked out, preventing accidental "database suicide".
*   **Capability-Based Delegation**: Users can only grant/revoke access to groups they actually possess. No more accidental privilege escalation.
*   **Privilege Safety**: Standard admins cannot modify other admins. Only `root` has absolute power.
*   **Clean Architecture**: Loosely coupled with HVPDB core via public APIs.

## Installation 📦

```bash
pip install hvpdb-perms
```

Or install from source:

```bash
cd hvpdb-perms
pip install .
```

## Usage 🛠️

The plugin integrates automatically with HVPDB when installed.

```python
from hvpdb.core import HVPDB

# 1. Initialize DB (Plugin loads automatically)
db = HVPDB("my_database.hvdb", "my_secret_key")

# 2. Access the Permission Manager
perms = db.plugins['perms']

# 3. Create a User (Requires Admin/Root context)
# Note: Context is usually set via authentication or CLI session
perms.create_user("alice", "secure_password")

# 4. Grant Access
perms.grant("alice", "sales_data")

# 5. Revoke Access
perms.revoke("alice", "sales_data")
```

## Security Model 🛡️

### 1. Root Immutability
The `root` user is the anchor of trust.
-   ❌ Cannot be renamed or deleted.
-   ❌ Permissions cannot be revoked.
-   ❌ Password/Attributes cannot be modified via this plugin.

### 2. Admin vs. User
-   **Admin**: Has full access (`*`) and can manage other users (except `root` and other Admins).
-   **User**: Can only access assigned groups. Can only delegate access to groups *they already have*.

### 3. Cluster Mode
⚠️ **Current Limitation**: This plugin currently **does not support Cluster Mode**. It will raise `NotImplementedError` to prevent false security assumptions.

## Limitations (v0.1) 🚧

*   **No Audit Log**: Actions (create, grant, revoke) are not yet logged to a separate audit trail.
*   **Admin-only List**: `list_users()` returns full user data and is restricted to admins.

---
*Built for HVPDB. Simple. Secure. Fast.*
