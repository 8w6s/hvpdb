import os
import sys
from typing import Optional
from .core import HVPDB

def redact_target(target: str) -> str:
    """Redacts password from URI or Target string for safe display."""
    if not target: return ""
    if "://" not in target:
        return target
    try:
        from urllib.parse import urlparse
        parsed = urlparse(target)
        if parsed.password:
            # Simple string replacement to avoid reconstruction issues
            return target.replace(parsed.password, "***")
        return target
    except:
        return target

def normalize_target(target: str) -> str:
    """Ensures target has correct extension or URI format."""
    if not target:
        return target
    if target.startswith("hvp://"):
        return target
    if not target.endswith(".hvp") and not target.endswith(".hvdb"):
        return target + ".hvp"
    return target

def get_db_password() -> Optional[str]:
    """Retrieves password from environment variable."""
    return os.environ.get("HVPDB_PASSWORD")

def connect_db(target: str, password: str = None) -> HVPDB:
    """
    Connects to HVPDB instance.
    Handles target normalization and password retrieval from env if not provided.
    """
    target = normalize_target(target)
    if password is None:
        password = get_db_password()
    return HVPDB(target, password)
