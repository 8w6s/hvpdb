import os
import time
import struct
import zlib
import msgpack
import zstandard as zstd
import portalocker
import uuid
import stat
from typing import Optional, List, Dict, Callable, Tuple

import warnings

WAL_MAGIC = b'HVPWAL'
WAL_VERSION = 2
MAX_ENTRY_SIZE = 64 * 1024 * 1024 # 64MB Safety Limit

class HVPWAL:
    """
    Write-Ahead Log Manager for HVPDB (WAL v2).
    Handles append-only logging with Transaction Support (ACID).
    
    File Format:
    [Header] (Optional/V2)
    - Magic (6 bytes): HVPWAL
    - Version (2 bytes): 0x0002
    - Salt (16 bytes)
    - KDF Len (2 bytes)
    - KDF Params (MsgPack)
    
    [Entries]
    - CRC (4 bytes)
    - Length (4 bytes)
    - Nonce (12 bytes)
    - Ciphertext (N bytes)
    """
    def __init__(self, log_path: str, security_context, compression_level: int = 3):
        self.log_path = log_path
        self.security = security_context
        self.cctx = zstd.ZstdCompressor(level=compression_level)
        self.dctx = zstd.ZstdDecompressor()

    def ensure_header(self, salt: bytes, kdf_params: dict):
        """Writes the WAL header if the file is new/empty."""
        if os.path.exists(self.log_path) and os.path.getsize(self.log_path) > 0:
            return

        with open(self.log_path, 'ab') as f:
            portalocker.lock(f, portalocker.LOCK_EX)
            try:
                if f.tell() == 0:
                    try:
                        os.chmod(self.log_path, 0o600)
                    except OSError:
                        pass
                    f.write(WAL_MAGIC)
                    f.write(WAL_VERSION.to_bytes(2, 'big'))
                    f.write(salt)
                    kdf_bytes = msgpack.packb(kdf_params)
                    f.write(len(kdf_bytes).to_bytes(2, 'big'))
                    f.write(kdf_bytes)
                    f.flush()
                    os.fsync(f.fileno()) # Ensure durability
            finally:
                portalocker.unlock(f)

    @staticmethod
    def read_header(log_path: str) -> Tuple[Optional[bytes], Optional[dict]]:
        """Reads Salt and KDF params from WAL header."""
        if not os.path.exists(log_path):
            return None, None
            
        with open(log_path, 'rb') as f:
            try:
                magic = f.read(6)
                if magic != WAL_MAGIC:
                    return None, None # Legacy or No Header
                
                version = int.from_bytes(f.read(2), 'big')
                if version != WAL_VERSION:
                    return None, None # Mismatch
                    
                salt = f.read(16)
                kdf_len = int.from_bytes(f.read(2), 'big')
                kdf_bytes = f.read(kdf_len)
                kdf_params = msgpack.unpackb(kdf_bytes)
                
                return salt, kdf_params
            except Exception:
                return None, None

    def write_batch(self, entries: List[dict]):
        """Writes multiple entries with a single fsync."""
        if not entries: return
        
        with open(self.log_path, 'ab') as f:
            portalocker.lock(f, portalocker.LOCK_EX)
            try:
                try:
                    os.chmod(self.log_path, 0o600) # Enforce 0600
                except OSError:
                    pass
                for entry in entries:
                    # Logic duplicated from _write_entry to avoid repeated file open/lock
                    packed = msgpack.packb(entry, use_bin_type=True)
                    compressed = self.cctx.compress(packed)
                    nonce, ciphertext = self.security.encrypt_chunk(compressed)
                    payload = nonce + ciphertext
                    crc = zlib.crc32(payload)
                    length = len(ciphertext)
                    
                    f.write(struct.pack('>I', crc))
                    f.write(struct.pack('>I', length))
                    f.write(nonce)
                    f.write(ciphertext)
                
                f.flush()
                os.fsync(f.fileno())
            finally:
                portalocker.unlock(f)

    def _write_entry(self, entry: dict):
        """Internal: Encrypts and writes a serialized entry to disk."""
        # Ensure header exists before writing data (V2 requirement)
        if self.security:
             self.ensure_header(self.security.get_salt(), self.security.get_kdf_params())

        # Serialize & Compress
        packed = msgpack.packb(entry, use_bin_type=True)
        compressed = self.cctx.compress(packed)
        
        # Encrypt
        nonce, ciphertext = self.security.encrypt_chunk(compressed)
        
        # Calculate Checksum (CRC32 of Nonce + Ciphertext)
        payload = nonce + ciphertext
        crc = zlib.crc32(payload)
        
        length = len(ciphertext)
        
        # Write to disk (Atomic Append)
        with open(self.log_path, 'ab') as f:
            portalocker.lock(f, portalocker.LOCK_EX)
            try:
                try:
                    os.chmod(self.log_path, 0o600) # Enforce 0600
                except OSError:
                    pass
                # Structure: CRC(4) | LEN(4) | NONCE(12) | DATA(...)
                f.write(struct.pack('>I', crc))         # 4 bytes
                f.write(struct.pack('>I', length))      # 4 bytes
                f.write(nonce)                          # 12 bytes
                f.write(ciphertext)                     # N bytes
                f.flush()
                # fsync for durability
                os.fsync(f.fileno())
            finally:
                portalocker.unlock(f)
        
    def begin_transaction(self) -> str:
        """Starts a new transaction and returns its ID."""
        return str(uuid.uuid4())

    def log_begin(self, sequence: int, txn_id: str):
        """Logs a BEGIN transaction marker."""
        if not self.security:
            raise ValueError("WAL Security context not initialized")
        
        entry = {
            "seq": sequence,
            "txn": txn_id,
            "type": "BEGIN",
            "ts": time.time()
        }
        self._write_entry(entry)

    def log_commit(self, sequence: int, txn_id: str):
        """Logs a COMMIT transaction marker."""
        if not self.security:
            raise ValueError("WAL Security context not initialized")
            
        entry = {
            "seq": sequence,
            "txn": txn_id,
            "type": "COMMIT",
            "ts": time.time()
        }
        self._write_entry(entry)

    def log_rollback(self, sequence: int, txn_id: str):
        """Logs a ROLLBACK transaction marker."""
        if not self.security:
            raise ValueError("WAL Security context not initialized")
            
        entry = {
            "seq": sequence,
            "txn": txn_id,
            "type": "ROLLBACK",
            "ts": time.time()
        }
        self._write_entry(entry)

    def append(self, sequence: int, op: str, group: str, doc_id: str, data: dict, txn_id: str = None, before_image: dict = None):
        """Appends a single data operation to the WAL."""
        if not self.security:
            raise ValueError("WAL Security context not initialized")

        # Auto-generate txn_id if not provided (Implicit Transaction)
        # Note: In strict mode, caller should always provide txn_id.
        if not txn_id:
            txn_id = str(uuid.uuid4())

        entry = {
            "seq": sequence,
            "txn": txn_id,
            "type": "DATA",
            "op": op,
            "g": group,
            "id": doc_id,
            "d": data,
            "b": before_image,
            "ts": time.time()
        }
        self._write_entry(entry)

    def append_batch(self, sequence: int, operations: List[dict], txn_id: str):
        """Appends a batch of operations. Deprecated in favor of explicit BEGIN/COMMIT blocks but kept for compatibility."""
        # For V2, we should map this to a proper transaction block if possible, 
        # but for now we just write a 'batch' op entry.
        # Ideally, core should loop and call append() inside a txn.
        if not self.security:
            raise ValueError("WAL Security context not initialized")

        entry = {
            "seq": sequence,
            "txn": txn_id,
            "type": "DATA",
            "op": "batch",
            "d": operations,
            "ts": time.time()
        }
        self._write_entry(entry)

    def replay(self, last_sequence: int, apply_callback: Callable[[dict], None]) -> int:
        """
        Replays the log with Transaction Isolation.
        Only applies operations from COMMITTED transactions.
        Uncommitted or Rolled-back transactions are ignored (Crash Recovery).
        """
        if not os.path.exists(self.log_path):
            return 0
            
        replayed_count = 0
        
        # Buffer for uncommitted transactions: {txn_id: [entries]}
        txn_buffer: Dict[str, List[dict]] = {}
        
        # Set of committed transaction IDs (to handle cases where we see data after commit? unlikely in WAL)
        # Actually, WAL is strictly ordered. We just need to buffer until we see COMMIT.
        
        with open(self.log_path, 'rb') as f:
            portalocker.lock(f, portalocker.LOCK_SH)
            try:
                # SKIP HEADER IF PRESENT
                header_magic = f.read(6)
                if header_magic == WAL_MAGIC:
                    # It's V2 with Header, skip rest of header
                    # Magic(6) + Version(2) + Salt(16) + KDFLen(2) + KDFBytes(...)
                    
                    version = int.from_bytes(f.read(2), 'big')
                    if version != WAL_VERSION:
                        warnings.warn(f"WAL Version Mismatch: Expected {WAL_VERSION}, got {version}. Treating as corrupt/legacy.")
                        # If strict, we should stop or error. For now, try to proceed or stop?
                        # Given it's a version mismatch, we probably can't read the header correctly.
                        # Rewind to 0 and try legacy? Or just stop.
                        # If header magic matched, it IS a HVPWAL file, just wrong version.
                        # Stopping is safer.
                        return 0

                    f.read(16) # Salt
                    kdf_len = int.from_bytes(f.read(2), 'big')
                    f.read(kdf_len) # KDF Params
                else:
                    # No header or Legacy, rewind to 0
                    f.seek(0)

                while True:
                    # 1. Read Header (CRC + Len) = 8 bytes
                    header = f.read(8)
                    if not header or len(header) < 8:
                        break
                        
                    stored_crc, length = struct.unpack('>II', header)
                    
                    # Sanity Check
                    if length == 0 or length > MAX_ENTRY_SIZE:
                        warnings.warn(f"WAL corruption detected: Entry size {length} invalid. Stopping replay.")
                        break

                    # 2. Read Payload (Nonce + Data)
                    payload_len = 12 + length
                    payload = f.read(payload_len)
                    
                    if len(payload) != payload_len:
                        # Treat truncated entry as end-of-log
                        warnings.warn("WAL truncated at end. Stopping replay.")
                        break
                        
                    # 3. Verify Checksum
                    computed_crc = zlib.crc32(payload) & 0xffffffff
                    stored_crc &= 0xffffffff # Normalize
                    
                    if computed_crc != stored_crc:
                        warnings.warn("WAL CRC mismatch (corruption or partial write). Stopping replay.")
                        break
                        
                    # 4. Decrypt & Decompress
                    nonce = payload[:12]
                    ciphertext = payload[12:]
                    
                    try:
                        # Symmetric Decrypt (Use decrypt_chunk if available, else standard decrypt)
                        # Ensure we handle nonce correctly
                        if hasattr(self.security, 'decrypt_chunk'):
                            compressed = self.security.decrypt_chunk(nonce, ciphertext)
                        else:
                            # Fallback if decrypt_chunk not implemented yet
                            compressed = self.security.decrypt(nonce, ciphertext)
                            
                        packed = self.dctx.decompress(compressed)
                        entry = msgpack.unpackb(packed, raw=False)
                        
                        seq = entry.get("seq", 0)
                        
                        # Only process if newer than snapshot
                        if seq > last_sequence:
                            entry_type = entry.get("type", "DATA") # Default to DATA for V1 compat
                            txn_id = entry.get("txn")
                            
                            # V1 Compatibility: No txn_id, treat as auto-commit
                            if not txn_id:
                                # Legacy V1 entry
                                apply_callback(entry)
                                replayed_count += 1
                                continue

                            if entry_type == "BEGIN":
                                txn_buffer[txn_id] = []
                                
                            elif entry_type == "DATA":
                                # If we missed the BEGIN (e.g. log rotation?), start buffering anyway
                                if txn_id not in txn_buffer:
                                    txn_buffer[txn_id] = []
                                txn_buffer[txn_id].append(entry)
                                
                            elif entry_type == "COMMIT":
                                if txn_id in txn_buffer:
                                    # Apply all buffered operations
                                    for buffered_entry in txn_buffer[txn_id]:
                                        apply_callback(buffered_entry)
                                        replayed_count += 1
                                    # Clear buffer
                                    del txn_buffer[txn_id]
                                    
                            elif entry_type == "ROLLBACK":
                                if txn_id in txn_buffer:
                                    # Discard buffer
                                    del txn_buffer[txn_id]
                            
                    except Exception as e:
                        warnings.warn(f"WAL Entry Decryption failed: {e}")
                        break
                        
            finally:
                portalocker.unlock(f)
                
        return replayed_count

    def truncate(self):
        """Clears the WAL file (typically after a successful checkpoint)."""
        # Fix Race: Lock BEFORE truncate
        # Open in 'a+b' to avoid auto-truncation on open ('w' truncates)
        with open(self.log_path, 'a+b') as f:
            portalocker.lock(f, portalocker.LOCK_EX)
            try:
                # Now we have exclusive lock, safe to wipe
                f.seek(0)
                f.truncate(0)
                
                try:
                    os.chmod(self.log_path, 0o600) # Enforce 0600
                except OSError:
                    pass
                
                # Re-write Header if Security Context is available
                if self.security:
                    f.write(WAL_MAGIC)
                    f.write(WAL_VERSION.to_bytes(2, 'big'))
                    f.write(self.security.get_salt())
                    kdf_bytes = msgpack.packb(self.security.get_kdf_params())
                    f.write(len(kdf_bytes).to_bytes(2, 'big'))
                    f.write(kdf_bytes)
                    f.flush()
                    os.fsync(f.fileno())
            finally:
                portalocker.unlock(f)
