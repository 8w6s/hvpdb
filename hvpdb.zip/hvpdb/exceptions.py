class HVPError(Exception):
    """Base exception for HVPDB."""
    pass

class AuthError(HVPError):
    """Authentication failed (wrong password or corrupted header)."""
    pass

class ConsistencyError(HVPError):
    """Database integrity check failed."""
    pass
