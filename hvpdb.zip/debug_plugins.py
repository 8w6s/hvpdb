import sys
if sys.version_info < (3, 10):
    from importlib_metadata import entry_points
else:
    from importlib.metadata import entry_points

print(f"Python: {sys.version}")

try:
    eps = entry_points(group='hvpdb.plugins')
    print("Found via group arg:", eps)
    for ep in eps:
        print(f" - {ep.name} -> {ep.value}")
except TypeError:
    print("Old style entry_points()")
    eps = entry_points()
    if hasattr(eps, 'select'):
        print("Using select()")
        found = eps.select(group='hvpdb.plugins')
        for ep in found:
            print(f" - {ep.name} -> {ep.value}")
    else:
        print("Using dict access")
        found = eps.get('hvpdb.plugins', [])
        for ep in found:
            print(f" - {ep.name} -> {ep.value}")
