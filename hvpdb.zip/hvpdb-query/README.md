# hvpdb-query

Polyglot Query Engine for HVPDB.

## Features
- **SQL Support**: `SELECT`, `INSERT`
- **Mongo Support**: `db.collection.find()`, `insert()`
- **Redis Support**: `GET`, `SET` (Key-Value simulation)

## Installation
```bash
pip install .
```

## Usage
Inside HVPDB Shell:
```bash
hvpdb > query "SELECT * FROM users WHERE role=admin"
hvpdb > query "db.products.find({'category': 'electronics'})"
hvpdb > query "SET config_mode debug"
```
