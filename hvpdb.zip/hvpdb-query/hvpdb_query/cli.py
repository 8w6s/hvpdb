import typer
import os
from typing import Optional
from rich.console import Console
from rich.table import Table
from .parser import PolyglotParser
from .engine import QueryEngine
from hvpdb.utils import connect_db

app = typer.Typer(help="Polyglot Query Engine (SQL, Mongo, Redis)")
console = Console()

@app.command(name="run")
def run_query(
    query: str = typer.Argument(..., help="Query string (SQL, Mongo, Redis)"),
    target: str = typer.Argument(..., help="Database Path/URI"),
    password: Optional[str] = typer.Argument(None, help="Database Password"),
):
    """
    Execute a polyglot query against an HVPDB database.
    
    Examples:
      hvpdb query run "SELECT * FROM users" mydb.hvp
      hvpdb query run "db.users.find({'role': 'admin'})" mydb.hvp
      hvpdb query run "GET config_key" mydb.hvp
    """
    try:
        db = connect_db(target, password)
    except Exception as e:
        console.print(f"[red]Connection Failed: {e}[/red]")
        raise typer.Exit(1)

    # Parse
    parser = PolyglotParser()
    engine = QueryEngine(db)

    try:
        plan = parser.parse(query)
        if not plan:
            console.print("[red]Invalid Query Syntax or Unsupported Language.[/red]")
            raise typer.Exit(1)
            
        # Execute
        results = engine.execute(plan)
        
        # Display
        if isinstance(results, list):
            console.print(f"[green]Found {len(results)} results.[/green]")
            if results:
                # Table View
                cols = set()
                # Sample first few for columns
                for r in results[:20]: 
                    if isinstance(r, dict):
                        cols.update(r.keys())
                
                if cols:
                    cols = sorted(list(cols))
                    table = Table(show_header=True)
                    for c in cols: table.add_column(c)
                    for r in results:
                        if isinstance(r, dict):
                            table.add_row(*[str(r.get(c, "")) for c in cols])
                        else:
                            # Fallback for non-dict items in list?
                            pass
                    console.print(table)
                else:
                    console.print(results)
        else:
            console.print(f"[green]Result:[/green] {results}")

    except Exception as e:
        console.print(f"[red]Query Execution Error: {e}[/red]")
        raise typer.Exit(1)
