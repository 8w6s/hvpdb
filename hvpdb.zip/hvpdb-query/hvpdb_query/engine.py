class QueryEngine:
    def __init__(self, db):
        self.db = db

    def execute(self, plan):
        if not plan: return None
        
        lang = plan.get("lang")
        
        if lang == "sql":
            return self._exec_sql(plan)
        elif lang == "mongo":
            return self._exec_mongo(plan)
        elif lang == "redis":
            return self._exec_redis(plan)
        elif plan.get("type") == "search":
             # Fallback search
             return "Basic search not implemented in engine yet."
        
        return None

    def _exec_sql(self, plan):
        op = plan["op"]
        table = plan["table"]
        
        if table not in self.db.get_all_groups():
            return f"Error: Table '{table}' not found."
            
        grp = self.db.group(table)
        
        if op == "select":
            where = plan.get("where")
            query = {}
            if where:
                # Basic WHERE parsing: key = value
                if "=" in where:
                    k, v = [x.strip() for x in where.split("=", 1)]
                    # Auto-type
                    if v.isdigit(): v = int(v)
                    elif v.startswith("'") and v.endswith("'"): v = v[1:-1]
                    query[k] = v
            
            docs = grp.find(query)
            
            # Field Selection
            fields = plan.get("fields")
            if fields and fields != "*":
                keys = [k.strip() for k in fields.split(",")]
                filtered_docs = []
                for d in docs:
                    new_d = {k: d.get(k) for k in keys if k in d}
                    filtered_docs.append(new_d)
                return filtered_docs
                
            return docs

        elif op == "insert":
            data = plan.get("data")
            if data:
                res = grp.insert(data)
                self.db.commit()
                return f"Inserted 1 row. ID: {res['_id']}"
            return "Insert failed: No data parsed."

        return "Unknown SQL operation."

    def _exec_mongo(self, plan):
        col_name = plan["collection"]
        op = plan["op"]
        args = plan["args"]
        
        if col_name not in self.db.get_all_groups() and op != "insert":
             # Auto-create on insert, but warn on find
             return f"Error: Collection '{col_name}' not found."
             
        grp = self.db.group(col_name)
        
        if op == "find":
            return grp.find(args)
        elif op == "insert":
            res = grp.insert(args)
            self.db.commit()
            return res
        elif op == "count":
            return grp.count()
            
        return f"Mongo op '{op}' not supported."

    def _exec_redis(self, plan):
        # Redis simulation: Use a 'redis' group or KV store behavior
        # Let's map Redis to a group named 'redis_kv'
        grp = self.db.group("redis_kv")
        
        op = plan["op"]
        key = plan["key"]
        
        if op == "GET":
            doc = grp.find_one({"_id": key})
            if doc:
                return doc.get("value")
            return None
            
        elif op == "SET":
            val = plan["value"]
            # Upsert
            existing = grp.find_one({"_id": key})
            if existing:
                grp.update({"_id": key}, {"value": val})
            else:
                grp.insert({"_id": key, "value": val}) # _id is key
            self.db.commit()
            return "OK"
            
        return "Unknown Redis command."
