import re
import json
import shlex

class PolyglotParser:
    def parse(self, query: str):
        query = query.strip()
        if not query:
            return None
            
        # Detect Language
        if query.lower().startswith(("select", "insert", "update", "delete")):
            return self._parse_sql(query)
        elif query.startswith("db."):
            return self._parse_mongo(query)
        elif query.upper().startswith(("GET", "SET", "DEL", "KEYS")):
            return self._parse_redis(query)
        else:
            # Default to basic search if key=value
            if "=" in query:
                return {"type": "search", "query": query}
            return None

    def _parse_sql(self, query):
        # Very basic SQL Parser
        q_lower = query.lower()
        
        if q_lower.startswith("select"):
            # SELECT * FROM table WHERE ...
            match = re.match(r"select\s+(.*?)\s+from\s+(\w+)(?:\s+where\s+(.*))?", query, re.IGNORECASE)
            if match:
                fields, table, where = match.groups()
                return {
                    "lang": "sql",
                    "op": "select",
                    "table": table,
                    "fields": fields.strip(),
                    "where": where.strip() if where else None
                }
        
        elif q_lower.startswith("insert"):
            # INSERT INTO table VALUES (...)
            # INSERT INTO table JSON '{...}'
            match = re.match(r"insert\s+into\s+(\w+)\s+(.*)", query, re.IGNORECASE)
            if match:
                table, rest = match.groups()
                # Try JSON format
                if "json" in rest.lower():
                     json_part = re.search(r"json\s+'(.*)'", rest, re.IGNORECASE)
                     if json_part:
                         val_str = json_part.group(1)
                         # Fix single quotes
                         if "'" in val_str:
                             val_str = val_str.replace("'", '"')
                         try:
                             data = json.loads(val_str)
                             return {
                                 "lang": "sql",
                                 "op": "insert",
                                 "table": table,
                                 "data": data
                             }
                         except:
                             pass
                
                return {
                    "lang": "sql",
                    "op": "insert",
                    "table": table,
                    "raw": rest
                }

        return None

    def _parse_mongo(self, query):
        # db.collection.op(args)
        match = re.match(r"db\.(\w+)\.(\w+)\((.*)\)", query)
        if match:
            collection, op, args = match.groups()
            
            # Parse Args (Expect JSON)
            arg_data = {}
            if args.strip():
                try:
                    # Replace single quotes for python-style dicts
                    valid_json = args.replace("'", '"')
                    arg_data = json.loads(valid_json)
                except:
                    # Fallback: Treat as string or empty
                    pass
            
            return {
                "lang": "mongo",
                "collection": collection,
                "op": op,
                "args": arg_data
            }
        return None

    def _parse_redis(self, query):
        parts = shlex.split(query)
        cmd = parts[0].upper()
        
        if cmd == "GET":
            if len(parts) < 2: return None
            return {"lang": "redis", "op": "GET", "key": parts[1]}
        elif cmd == "SET":
            if len(parts) < 3: return None
            return {"lang": "redis", "op": "SET", "key": parts[1], "value": parts[2]}
            
        return None
